const RouteService = require("../../services/RouteService")
const DatabaseMock = require("../mocks/DatabaseMock")

describe("RouteService", () => {
	describe("getRoutes function", () => {
		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutes((error, routes) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle empty responses", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutes((error, routes) => {
				expect(error).toEqual("no response")
				callback()
			})
		})

		it("should return routes", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: [{
						ID: 1,
						NAME: "First Route",
						CITY: "London",
						COUNTRY: "UK",
						AQI: 0,
						CENTER_LAT: 10,
						CENTER_LON: 10
					}]
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutes((error, routes) => {
				expect(error).toEqual(null)
				expect(routes.length).toEqual(1)
				callback()
			})
		})
	})

	describe("getRoutesForCity function", () => {
		it("should require a city name", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.getRoutesForCity(null, (error, routes) => {
				expect(error).toEqual("city required")
				callback()
			})
		})

		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutesForCity("London", (error, routes) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle empty responses", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutesForCity("London", (error, routes) => {
				expect(error).toEqual("no response")
				callback()
			})
		})

		it("should return routes", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: [{
						ID: 1,
						NAME: "First Route",
						CITY: "London",
						COUNTRY: "UK",
						AQI: 0,
						CENTER_LAT: 10,
						CENTER_LON: 10
					}]
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutesForCity("London", (error, routes) => {
				expect(error).toEqual(null)
				expect(routes.length).toEqual(1)
				callback()
			})
		})
	})

	describe("getRoute function", () => {
		it("should require an id", (callback) => {
			const database = new DatabaseMock("Error", null)
			const routeService = new RouteService()
			routeService.getRoute(null, (error, route) => {
				expect(error).toEqual("id required")
				callback()
			})
		})

		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoute(1, (error, route) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle empty responses", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoute(1, (error, route) => {
				expect(error).toEqual("no response")
				callback()
			})
		})

		it("should return a route", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: [{
						ID: 1,
						NAME: "First Route",
						CITY: "London",
						COUNTRY: "UK",
						AQI: 0,
						CENTER_LAT: 10,
						CENTER_LON: 10
					}]
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoute(1, (error, route) => {
				expect(error).toEqual(null)
				expect(route.id).toEqual(1)
				callback()
			})
		})
	})

	describe("getRoutePoints function", () => {
		it("should require an id", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.getRoutePoints(null, (error, points) => {
				expect(error).toEqual("id required")
				callback()
			})
		})

		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutePoints(1, (error, points) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle empty responses", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutePoints(1, (error, points) => {
				expect(error).toEqual("no response")
				callback()
			})
		})

		it("should return points", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: [{
						ORDER_INDEX: 1,
						LAT: 10,
						LON: 10
					}]
				}
			})
			const routeService = new RouteService(database)
			routeService.getRoutePoints(1, (error, points) => {
				expect(error).toEqual(null)
				expect(points.length).toEqual(1)
				callback()
			})
		})
	})

	describe("createRoute function", () => {
		it("should require a name", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute(null, null, null, null, null, null, (error, response) => {
				expect(error).toEqual("name required")
				callback()
			})
		})

		it("should require a city", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", null, null, null, null, null, (error, response) => {
				expect(error).toEqual("city required")
				callback()
			})
		})

		it("should require a country", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", null, null, null, null, (error, response) => {
				expect(error).toEqual("country required")
				callback()
			})
		})

		it("should require a centerLat", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", null, null, null, (error, response) => {
				expect(error).toEqual("centerLat required")
				callback()
			})
		})

		it("should require a centerLon", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, null, null, (error, response) => {
				expect(error).toEqual("centerLon required")
				callback()
			})
		})

		it("should require points", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, 10, null, (error, response) => {
				expect(error).toEqual("points required")
				callback()
			})
		})

		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, 10, [], (error, response) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle an empty response", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, 10, [], (error, response) => {
				expect(error).toEqual("no response")
				callback()
			})
		})

		it("should create a route with no points", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: {
						insertId: 1
					}
				}
			})
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, 10, [], (error, response) => {
				expect(error).toEqual(null)
				expect(response.success).toEqual(true)
				callback()
			})
		})

		it("should create a route with points", (callback) => {
			const database = new DatabaseMock({
				"INSERT INTO ROUTES (NAME, CITY, COUNTRY, CENTER_LAT, CENTER_LON) VALUES ?": {
					error: null,
					response: {
						insertId: 1
					}
				},
				"INSERT INTO POINTS (ROUTE_ID, ORDER_INDEX, LAT, LON) VALUES ?": {
					error: null,
					response: {
						success: true
					}
				}
			})
			const routeService = new RouteService(database)
			routeService.createRoute("First Run", "London", "UK", 10, 10, [
				{
					orderIndex: 1,
					lat: 10,
					lon: 10
				}
			], (error, response) => {
				expect(error).toEqual(null)
				expect(response.success).toEqual(true)
				callback()
			})
		})
	})

	describe("createRoutePoints function", () => {
		it("should require an id", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoutePoints(null, null, (error, response) => {
				expect(error).toEqual("id required")
				callback()
			})
		})

		it("should require points", (callback) => {
			const database = new DatabaseMock()
			const routeService = new RouteService(database)
			routeService.createRoutePoints(1, null, (error, response) => {
				expect(error).toEqual("points required")
				callback()
			})
		})

		it("should handle errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const routeService = new RouteService(database)
			routeService.createRoutePoints(1, [], (error, response) => {
				expect(error).toEqual("Error")
				callback()
			})
		})
	})
})
