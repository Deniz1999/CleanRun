const AirQualityIndexService = require("../../services/AirQualityIndexService")
const DatabaseMock = require("../mocks/DatabaseMock")
const NetworkMock = require("../mocks/NetworkMock")

describe("AirQualityIndexService", () => {
	describe("updateAirQualityIndexForRoutes function", () => {
		it("should require routes", (callback) => {
			const database = new DatabaseMock()
			const network = new NetworkMock()
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes(null, (error, response) => {
				expect(error).toEqual("routes required")
				callback()
			})
		})

		it("should require routes with centers", (callback) => {
			const database = new DatabaseMock()
			const network = new NetworkMock()
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([], (error, response) => {
				expect(error).toEqual("routes required")
				callback()
			})
		})

		it("should update routes", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: []
				}
			})
			const network = new NetworkMock({
				"https://api.waqi.info/feed/geo:1;1/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 10 }}"
				},
				"https://api.waqi.info/feed/geo:2;2/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 20 }}"
				},
				"https://api.waqi.info/feed/geo:3;3/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 30 }}"
				}
			})
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([
				{
					id: 1,
					centerLat: 1,
					centerLon: 1
				},
				{
					id: 2,
					centerLat: 2,
					centerLon: 2
				},
				{
					id: 3,
					centerLat: 3,
					centerLon: 3
				}
			], (error, response) => {
				expect(error).toEqual(null)
				expect(response.success).toEqual(true)
				expect(database.values).toEqual([[10,1],[20,2],[30,3]])
				callback()
			})
		})

		it("should handle missing AQI data", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: []
				}
			})
			const network = new NetworkMock({
				"https://api.waqi.info/feed/geo:1;1/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 10 }}"
				},
				"https://api.waqi.info/feed/geo:2;2/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 20 }}"
				},
				"https://api.waqi.info/feed/geo:3;3/?token=123": {
					error: null,
					response: null,
					body: "{ \"data\": {}}"
				}
			})
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([
				{
					id: 1,
					centerLat: 1,
					centerLon: 1
				},
				{
					id: 2,
					centerLat: 2,
					centerLon: 2
				},
				{
					id: 3,
					centerLat: 3,
					centerLon: 3
				}
			], (error, response) => {
				expect(error).toEqual(null)
				expect(response.success).toEqual(true)
				expect(database.values).toEqual([[10,1],[20,2]])
				callback()
			})
		})

		it("should handle network errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: []
				}
			})
			const network = new NetworkMock({
				"*": {
					error: "Error",
					response: null,
					body: null
				}
			})
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([
				{
					id: 1,
					centerLat: 1,
					centerLon: 1
				}
			], (error, response) => {
				expect(error).toEqual("Error")
				callback()
			})
		})

		it("should handle invalid JSON", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: null,
					response: []
				}
			})
			const network = new NetworkMock({
				"*": {
					error: null,
					response: null,
					body: "{{}"
				}
			})
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([
				{
					id: 1,
					centerLat: 1,
					centerLon: 1
				}
			], (error, response) => {
				expect(error).toEqual("Invalid JSON")
				callback()
			})
		})

		it("should handle database errors", (callback) => {
			const database = new DatabaseMock({
				"*": {
					error: "Error",
					response: null
				}
			})
			const network = new NetworkMock({
				"*": {
					error: null,
					response: null,
					body: "{ \"data\": { \"aqi\": 20 }}"
				}
			})
			const airQualityIndexService = new AirQualityIndexService(database, network, "123")
			airQualityIndexService.updateAirQualityIndexForRoutes([
				{
					id: 1,
					centerLat: 1,
					centerLon: 1
				}
			], (error, response) => {
				expect(error).toEqual("Error")
				callback()
			})
		})
	})
})
