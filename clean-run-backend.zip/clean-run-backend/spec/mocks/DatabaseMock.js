"use strict"

module.exports = class Database {
	constructor(mockResponses) {
		this.values = []
		this.mockResponses = mockResponses
	}

	query(queryString, values, callback) {
		this.values.push(values)
		const mockResponse = this.mockResponses[queryString] || this.mockResponses["*"]
		callback(mockResponse.error, mockResponse.response)
	}
}
