"use strict"

module.exports = class Network {
	constructor(mockResponses) {
		this.mockResponses = mockResponses
	}

	get(url, callback) {
		const mockResponse = this.mockResponses[url] || this.mockResponses["*"]
		callback(mockResponse.error, mockResponse.response, mockResponse.body)
	}
}
