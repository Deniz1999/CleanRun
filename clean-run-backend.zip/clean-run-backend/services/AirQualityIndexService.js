"use strict"

module.exports = class AirQualityIndexService {
	constructor(database, network, token) {
		this.database = database
		this.network = network
		this.token = token
	}
	// This method accepts a list of routes and a callback method as arguments.
	// This method retrieves and updates the air quality index values for any given number of routes.
	// It calls the waqi.info API with the API token and the coordinates for the route to retrieve an air quality index value.
	updateAirQualityIndexForRoutes(routes, callback) {
		if (!routes) {
			callback("routes required", null)
			return
		}

		routes = routes.filter((item) => {
			return item.centerLat && item.centerLon
		})

		if (!routes.length) {
			callback("routes required", null)
			return
		}

		const promises = routes.map((route) => {
			return this.getAirQualityIndexForRoute(route)
		})

		Promise.all(promises).then((response) => {
			callback(null, {
				success: true
			})
		}).catch((error) => {
			callback(error, null)
		})
	}

	getAirQualityIndexForRoute(route) {
		const url = `https://api.waqi.info/feed/geo:${route.centerLat};${route.centerLon}/?token=${this.token}`
		return new Promise((resolve, reject) => {
			this.network.get(url, (error, response, body) => {
				if (error) {
					reject(error)
					return
				}

				try {
					body = JSON.parse(body)
					const aqi = body.data.aqi
					if (!aqi) {
						resolve()
						return
					}
					this.updateAirQualityIndexForRoute(route.id, aqi, resolve, reject)
				} catch (error) {
					reject("Invalid JSON")
				}
			})
		})
	}

	updateAirQualityIndexForRoute(id, aqi, resolve, reject) {
		// SQL query used to update the AQI value in the ROUTES table using the new air quality index value.
		const query = "UPDATE ROUTES SET AQI=? WHERE ID=?"
		this.database.query(query, [aqi, id], (error, response) => {
			if (error) {
				reject(error)
				return
			}

			resolve(response)
		})
	}
}
