"use strict"

const Route = require("../models/Route.js")
const Point = require("../models/Point.js")

module.exports = class RouteService {
	constructor(database) {
		this.database = database
	}

	getRoutes(callback) {
		const query = "SELECT ID, NAME, CITY, COUNTRY, AQI, CENTER_LAT, CENTER_LON FROM ROUTES"
		this.database.query(query, [], (error, response) => {
			if (error) {
				callback(error, null)
				return
			} else if (!response) {
				callback("no response", null)
				return
			}

			const routes = response.map((item) => {
				return Route.fromData(item)
			})

			callback(null, routes)
		})
	}

	getRoutesForCity(city, callback) {
		if (!city) {
			callback("city required", null)
			return
		}

		const query = "SELECT ID, NAME, CITY, COUNTRY, AQI, CENTER_LAT, CENTER_LON FROM ROUTES WHERE CITY=?"
		this.database.query(query, [city], (error, response) => {
			if (error) {
				callback(error, null)
				return
			} else if (!response) {
				callback("no response", null)
				return
			}

			const routes = response.map((item) => {
				return Route.fromData(item)
			})

			callback(null, routes)
		})
	}

	getRoute(id, callback) {
		if (!id) {
			callback("id required", null)
			return
		}

		const query = "SELECT ID, NAME, CITY, COUNTRY, AQI, CENTER_LAT, CENTER_LON FROM ROUTES WHERE ID=?"
		this.database.query(query, [id], (error, response) => {
			if (error) {
				callback(error, null)
				return
			} else if (!response || !response.length) {
				callback("no response", null)
				return
			}

			let route = Route.fromData(response[0])
			callback(null, route)
		})
	}

	getRoutePoints(id, callback) {
		if (!id) {
			callback("id required", null)
			return
		}

		const query = "SELECT ORDER_INDEX, LAT, LON FROM POINTS WHERE ROUTE_ID=?"
		this.database.query(query, [id], (error, response) => {
			if (error) {
				callback(error, null)
				return
			} else if (!response) {
				callback("no response", null)
				return
			}

			const points = response.map((item) => {
				return Point.fromData(item)
			})

			callback(null, points)
		})
	}

	createRoute(name, city, country, centerLat, centerLon, points, callback) {
		if (!name) {
			callback("name required", null)
			return
		} else if (!city) {
			callback("city required", null)
			return
		} else if (!country) {
			callback("country required", null)
			return
		} else if (!centerLat) {
			callback("centerLat required", null)
			return
		} else if (!centerLon) {
			callback("centerLon required", null)
			return
		} else if (!points) {
			callback("points required", null)
			return
		}

		const query = "INSERT INTO ROUTES (NAME, CITY, COUNTRY, CENTER_LAT, CENTER_LON) VALUES ?"
		this.database.query(query, [[[name, city, country, centerLat, centerLon]]], (error, response) => {
			if (error) {
				callback(error)
				return
			} else if (!response) {
				callback("no response", null)
				return
			}

			if (!points.length) {
				callback(null, {
					success: true
				})
				return
			}

			const id = response.insertId
			this.createRoutePoints(id, points, callback)
		})
	}

	createRoutePoints(id, points, callback) {
		if (!id) {
			callback("id required", null)
			return
		} else if (!points) {
			callback("points required", null)
			return
		}

		const pointsValues = points.map((point) => {
			return [id, point.orderIndex, point.lat, point.lon]
		})
		const query = "INSERT INTO POINTS (ROUTE_ID, ORDER_INDEX, LAT, LON) VALUES ?"
		this.database.query(query, [pointsValues], (error, response) => {
			if (error) {
				callback(error, null)
				return
			}

			callback(null, {
				success: true
			})
		})
	}
}
