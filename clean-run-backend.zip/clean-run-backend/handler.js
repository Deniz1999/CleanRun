"use strict"

const mysql = require("mysql")
const request = require("request")

const connection = mysql.createConnection({
	host: "cleanrun.cu4jopwyski3.us-east-1.rds.amazonaws.com",
	user: "admin",
	password: "tLUZHwX276tNHWpW",
	port: 3306,
	database: "cleanrun"
})

const RouteService = require("./services/RouteService.js")
const AirQualityIndexService = require("./services/AirQualityIndexService.js")

module.exports.getRoutes = (event, context, callback) => {
	context.callbackWaitsForEmptyEventLoop = false

	const cityName = event.path.cityName
	const routeService = new RouteService(connection)
	if (cityName) {
		routeService.getRoutesForCity(cityName, callback)
	} else {
		routeService.getRoutes(callback)
	}
}

module.exports.getRoute = (event, context, callback) => {
	context.callbackWaitsForEmptyEventLoop = false

	const id = event.path.id
	const routeService = new RouteService(connection)
	routeService.getRoute(id, (error, route) => {
		if (error) {
			callback(error)
			return
		}

		routeService.getRoutePoints(id, (error, points) => {
			route.points = points
			callback(null, route)
		})
	})
}

module.exports.createRoute = (event, context, callback) => {
	context.callbackWaitsForEmptyEventLoop = false

	const name = event.body.name
	const city = event.body.city
	const country = event.body.country
	const centerLat = event.body.centerLat
	const centerLon = event.body.centerLon
	const points = event.body.points
	const routeService = new RouteService(connection)
	routeService.createRoute(name, city, country, centerLat, centerLon, points, callback)
}

module.exports.updateAirQualityIndexForRoutes = (event, context, callback) => {
	context.callbackWaitsForEmptyEventLoop = false

	const routeService = new RouteService(connection)
	routeService.getRoutes((error, routes) => {
		if (error) {
			callback(error)
			return
		}

		const token = "7b946302be4645c5f491e3820e1b16c6773fafef"
		const airQualityIndexService = new AirQualityIndexService(connection, request, token)
		airQualityIndexService.updateAirQualityIndexForRoutes(routes, callback)
	})
}
