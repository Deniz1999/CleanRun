import { Injectable } from "@angular/core"
import { HttpClient } from "@angular/common/http"
import { Observable } from "rxjs"

@Injectable({
	providedIn: "root"
})

export class NetworkService {

	url = "https://m4gxnee7wl.execute-api.us-east-1.amazonaws.com/dev/"

	constructor(private http: HttpClient) {}

	get(path: string, callback) {
		this.http.get(this.url + path).subscribe((response) => {
			callback(null, response)
		}, (error) => {
			callback(error, null)
		})
	}

	post(path: string, data: any, callback) {
		this.http.post(this.url + path, data).subscribe((response) => {
			callback(null, response)
		}, (error) => {
			callback(error, null)
		})
	}

	call(url: string, callback) {
		this.http.get(url).subscribe((response) => {
			callback(null, response)
		}, (error) => {
			callback(error, null)
		})
	}
}
