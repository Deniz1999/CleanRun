import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router"
import { RouteService } from "../services/route.service"
import { Route } from "../models/route"

@Component({
	selector: "app-route",
	templateUrl: "./route.component.html",
	styleUrls: ["./route.component.less"]
})

export class RouteComponent implements OnInit {

	route: Route

	constructor(private aRoute: ActivatedRoute, private routeService: RouteService) {}

	ngOnInit() {
		var id = this.aRoute.snapshot.paramMap.get("id")

		this.routeService.getRoute(id, (error, route) => {
			if (error) {
				alert("Error")
				return
			}

			this.route = route
		})
	}
}
