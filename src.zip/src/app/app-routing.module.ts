import { NgModule } from "@angular/core"
import { Routes, RouterModule } from "@angular/router"
import { HomeComponent } from "./home/home.component"
import { RoutesComponent } from "./routes/routes.component"
import { RouteComponent } from "./route/route.component"
import { CreateRouteComponent } from "./create-route/create-route.component"

const routes: Routes = [
	{
		path: "",
		redirectTo: "/home",
		pathMatch: "full"
	},
	{
		path: "home",
		component: HomeComponent
	},
	{
		path: "routes",
		component: RoutesComponent
	},
	{
		path: "routes/:id",
		component: RouteComponent
	},
	{
		path: "create",
		component: CreateRouteComponent
	}
]

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})

export class AppRoutingModule {}
