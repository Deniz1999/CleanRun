import { Component, Input, OnInit, Output, EventEmitter } from "@angular/core"

import { Point } from "../models/point"
import { MapService } from "../services/map.service"

@Component({
	selector: "app-map",
	templateUrl: "./map.component.html",
	styleUrls: ["./map.component.less"]
})

export class MapComponent implements OnInit {

	@Input() center: Point
	@Input() points: Point[] = []
	@Input() isEditable: boolean = false

	@Output() pointsUpdated = new EventEmitter()

	private map: any

	private newPoints: Point[] = []

	constructor(private mapService: MapService) {}

	ngOnInit() {
		this.map = this.mapService.createMap(this.center, this.points, (point) => {
			if (!this.isEditable || this.newPoints.length >= 3) {
				return
			}

			point.index = this.newPoints.length
			this.newPoints.push(point)
			this.mapService.addPoint(this.map, point)

			if (this.newPoints.length == 3) {
				this.updateRoute()
			}
		})
	}

	updateRoute() {
		this.mapService.setPoints(this.map, this.newPoints)
		this.pointsUpdated.emit(this.newPoints)
	}
}
