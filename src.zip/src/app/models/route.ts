import { Point } from "./point"

export class Route {
	id: number
	name: string
	city: string
	country: string
	aqi: number
	center: Point
	points: Point[] = []
	airQualityDescription: string = ""
	airQualityDescriptionColor: string = "#FFFFFF"

	constructor(id: number,
		name: string,
		city: string,
		country: string,
		aqi: number,
		centerLat: number,
		centerLon: number) {
		this.id = id
		this.name = name
		this.city = city
		this.country = country
		this.aqi = aqi
		this.center = new Point(0, centerLat, centerLon)

		if (!this.aqi) {
			return
		}

		if (this.aqi < 50) {
			this.airQualityDescription = "Good"
			this.airQualityDescriptionColor = "#00E400"
		} else if (this.aqi < 100) {
			this.airQualityDescription = "Moderate"
			this.airQualityDescriptionColor = "#FFFF00"
		} else if (this.aqi < 150) {
			this.airQualityDescription = "Unhealthy for Sensitive Groups"
			this.airQualityDescriptionColor = "#FE7D00"
		} else if (this.aqi < 200) {
			this.airQualityDescription = "Unhealthy"
			this.airQualityDescriptionColor = "#FF0000"
		} else if (this.aqi < 300) {
			this.airQualityDescription = "Very Unhealthy"
			this.airQualityDescriptionColor = "#99004C"
		} else {
			this.airQualityDescription = "Hazardous"
			this.airQualityDescriptionColor = "#7E0023"
		}
	}

	static fromJson(data: any): Route {
		let route = new Route(data.id, data.name, data.city, data.country, data.aqi, data.centerLat, data.centerLon)
		if (data.points) {
			route.points = data.points.map((item) => {
				return Point.fromJson(item)
			})
		}
		return route
	}
}
