import { Component, OnInit } from "@angular/core"

import { MapService } from "../services/map.service"
import { RouteService } from "../services/route.service"
import { Point } from "../models/point"

@Component({
	selector: "app-create-route",
	templateUrl: "./create-route.component.html",
	styleUrls: ["./create-route.component.less"]
})

export class CreateRouteComponent implements OnInit {

	center: Point = new Point(0, 51.509865, -0.118092)
	name: string
	city: string
	country: string
	points: Point[] = []

	constructor(private routeService: RouteService, private mapService: MapService) {}

	ngOnInit() {}

	didPressSave() {
		this.center = this.mapService.calculateCenter(this.points)

		this.routeService.createRoute(this.name, this.city, this.country, this.center, this.points, (error, success) => {
			if (error) {
				alert(error)
				return
			}

			this.name = null
			this.city = null
			this.country = null
			this.points = []
		})
	}

	updatePoints(points: Point[]) {
		this.points = points
	}
}
