import { Component, OnInit } from "@angular/core"

import { RouteService } from "../services/route.service"
import { Route } from "../models/route"

@Component({
	selector: "app-routes",
	templateUrl: "./routes.component.html",
	styleUrls: ["./routes.component.less"]
})

export class RoutesComponent implements OnInit {

	routes: Route[] = []

	constructor(private routeService: RouteService) {}

	ngOnInit() {
		this.routeService.getRoutes((error, routes) => {
			if (error) {
				alert(error)
				return
			}

			this.routes = routes
		})
	}
}
