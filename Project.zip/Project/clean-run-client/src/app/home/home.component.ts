/**  
	import @angular/core imports Angular's core functionality and utilities, defines the class infrastructure for components, and event handling.
*/

import { Component } from "@angular/core"
/**
Component is a decorator that marks a class as an Angular component 
*
The code below will redirect to the home page.
*/
@Component({
	selector: "app-home",
	templateUrl: "./home.component.html",
	styleUrls: ["./home.component.less"]
})

export class HomeComponent {}


