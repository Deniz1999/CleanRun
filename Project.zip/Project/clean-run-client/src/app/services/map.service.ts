/*
The code below will render the maps, plot the routes and allow the user to create routes interactively. 
*/

import { Injectable } from "@angular/core"

import { Point } from "../models/point"
import { NetworkService } from "../services/network.service"

declare const turf: any
declare const mapboxgl: any

@Injectable({
	providedIn: "root"
})

export class MapService {

	private accessToken = "pk.eyJ1IjoiZGVuaXprYXpkYWw5OSIsImEiOiJjazdjZHVreDAwNWxzM3JvNTRubDNqZjB6In0.vm1Yu8bYhFwxyIq6ZEVmYA"

	constructor(private networkService: NetworkService) {}

	addPoint(map: any, point: Point) {
		var el = document.createElement("div")
		el.className = "marker"
		el.style.cssText = "width: 20px; height: 20px; background: blue;"

		new mapboxgl.Marker(el)
			.setLngLat([point.lon, point.lat])
			.addTo(map)
	}

	calculateCenter(points: Point[]): Point {
		let lowestLat = null
		let highestLat = null
		let lowestLon = null
		let highestLon = null

		points.forEach((point) => {
			if (lowestLat == null || point.lat < lowestLat) {
				lowestLat = point.lat
			}

			if (highestLat == null || point.lat > highestLat) {
				highestLat = point.lat
			}

			if (lowestLon == null || point.lon < lowestLon) {
				lowestLon = point.lon
			}

			if (highestLon == null ||point.lon > highestLon) {
				highestLon = point.lon
			}
		})

		let latDifference = highestLat - lowestLat
		let lonDifference = highestLon - lowestLon

		return new Point(0, lowestLat + (latDifference / 2), lowestLon + (lonDifference / 2))
	}

	createMap(center: Point, points: Point[], clickHandler: (point: Point) => void): any {
		mapboxgl.accessToken = this.accessToken

		const map = new mapboxgl.Map({
			container: "map",
			style: "mapbox://styles/mapbox/light-v10",
			center: center,
			zoom: 12
		})

		map.on("load", () => {
			map.addSource("route", {
				type: "geojson",
				data: turf.featureCollection([])
			})

			map.addLayer({
				id: "routeline-active",
				type: "line",
				source: "route",
				layout: {
					"line-join": "round",
					"line-cap": "round"
				},
				paint: {
					"line-color": "#3887be",
					"line-width": [
						"interpolate",
						["linear"],
						["zoom"],
						12, 3,
						22, 12
					]
				}
			}, "waterway-label")

			this.setPoints(map, points)

			map.on("click", (event) => {
				const point = new Point(0, event.lngLat.lat, event.lngLat.lng)
				clickHandler(point)
			})
		})

		return map
	}

	setPoints(map: any, points: Point[]) {
		if (!points.length) {
			return
		}

		var coordinates = points.map((point) => {
			return [point.lon, point.lat]
		})

		var distributions = []

		for (var i = 0; i < coordinates.length - 1; i++) {
			distributions.push(i + "," + (i + 1))
		}

		const pointsString = coordinates.join(";")
		const distributionsString = distributions.join(";")

		const mapEndpoint = `https://api.mapbox.com/optimized-trips/v1/mapbox/walking/${pointsString}?distributions=${distributionsString}&overview=full&steps=true&geometries=geojson&source=first&access_token=${this.accessToken}`

		this.networkService.call(mapEndpoint, (error, response) => {
			var routeGeoJSON = turf.featureCollection([turf.feature(response.trips[0].geometry)])
			map.getSource("route").setData(routeGeoJSON)
		})
	}
}
