"use strict"
// The class is instantiated with an orderIndex, a lat value and a lon value. 
module.exports = class Point {
	constructor(orderIndex, lat, lon) {
		this.orderIndex = orderIndex
		this.lat = lat
		this.lon = lon

	}

	static fromData(data) {
		return new Point(data.ORDER_INDEX, data.LAT, data.LON)
	}
}
