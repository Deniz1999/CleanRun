"use strict"

module.exports = class Route {
	constructor(id, name, city, country, aqi, centerLat, centerLon) {
		this.id = id
		this.name = name
		this.city = city
		this.country = country
		this.aqi = aqi
		this.centerLat = centerLat
		this.centerLon = centerLon
		this.points = []
	}

	static fromData(data) {
		return new Route(data.ID, data.NAME, data.CITY, data.COUNTRY, data.AQI, data.CENTER_LAT, data.CENTER_LON)
	}
}
