/*
The router parses the URL path, and serves components in the <router-outlet> tag in the app.component.html file
The class contains an array of Route objects, initialised to an empty array. 
The constructor injects an instance of the RouteService
The ngOnInit method is called when the view has been initialised., which will call the getRoutes method.
*
*/

import { Component, OnInit } from "@angular/core"

import { RouteService } from "../services/route.service"
import { Route } from "../models/route"

@Component({
	selector: "app-routes",
	templateUrl: "./routes.component.html",
	styleUrls: ["./routes.component.less"]
})

export class RoutesComponent implements OnInit {

	routes: Route[] = []

	constructor(private routeService: RouteService) {}

	ngOnInit() {
		this.routeService.getRoutes((error, routes) => {
			if (error) {
				alert(error)
				return
			}

			this.routes = routes
		})
	}
}
