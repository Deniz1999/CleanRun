/** 
	import MapService, RouteService, and Point to use Angular maps 
	Component is a decorator that will redirect to the create route page. 
*

*/

import { Component, OnInit } from "@angular/core"

import { MapService } from "../services/map.service"
import { RouteService } from "../services/route.service"
import { Point } from "../models/point"

@Component({
	selector: "app-create-route",
	templateUrl: "./create-route.component.html",
	styleUrls: ["./create-route.component.less"]
})

export class CreateRouteComponent implements OnInit {

	center: Point = new Point(0, 51.509865, -0.118092)
	name: string
	city: string
	country: string
	points: Point[] = []

	constructor(
		private routeService: RouteService,
		private mapService: MapService) {}

	ngOnInit() {}

	didPressSave() {
		if (!this.points) {
			alert("Use the map to create a route")
			return
		}

		if (!this.name || !this.city || !this.country) {
			alert("Enter a name, city and country for your route")
			return
		}

		this.center = this.mapService.calculateCenter(this.points)

		this.routeService.createRoute(this.name, this.city, this.country, this.center, this.points, (error, success) => {
			if (error) {
				alert(error)
				return
			}

			this.name = null
			this.city = null
			this.country = null
			this.points = []

			alert("Your route was created")
		})
	}

	updatePoints(points: Point[]) {
		this.points = points
	}
}
