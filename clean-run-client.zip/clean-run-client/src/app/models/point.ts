export class Point {
	index: number
	lat: number
	lon: number

/**
The Point and Route classes describe the data models used in this application.

*/
	constructor(index: number,
		lat: number,
		lon: number) {
		this.index = index
		this.lat = lat
		this.lon = lon
	}

	static fromJson(data: any): Point {
		return new Point(data.orderIndex, data.lat, data.lon)
	}
}

