/*
The code below will retrieve a list of routes, which will require an instance of the NetworkService to communicate with the API. 
*/

import { Injectable } from "@angular/core"

import { Route } from "../models/route"
import { Point } from "../models/point"
import { NetworkService } from "../services/network.service"

@Injectable({
	providedIn: "root"
})

export class RouteService {

	constructor(private networkService: NetworkService) {}

	createRoute(name: string, city: string, country: string, center: Point, points: Point[], callback: (error: Error, success: boolean) => void): void {
		this.networkService.post("routes", {
			name: name,
			city: city,
			country: country,
			centerLat: center.lat,
			centerLon: center.lon,
			points: points.map((point) => {
				return {
					orderIndex: point.index,
					lat: point.lat,
					lon: point.lon
				}
			})
		}, (error, response) => {
			if (error) {
				callback(error, false)
				return
			}

			callback(null, true)
		})
	}

	getRoute(id: string, callback: (error: Error, route: Route) => void): void {
		this.networkService.get("routes/" + id, (error, response) => {
			if (error) {
				callback(error, null)
				return
			}

			const route = Route.fromJson(response)

			callback(null, route)
		})
	}

	getRoutes(callback: (error: Error, routes: Route[]) => void): void {
		this.networkService.get("routes", (error, response) => {
			if (error) {
				callback(error, [])
				return
			}

			const routes = response.map((data) => {
				return Route.fromJson(data)
			})

			callback(null, routes)
		})
	}
}
